var namespaces =
[
    [ "proccommand-Dictionary", "dd/d29/namespaceproccommand-_dictionary.html", null ]
];