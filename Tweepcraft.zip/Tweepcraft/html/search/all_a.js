var searchData=
[
  ['objectmenu',['objectMenu',['../dd/d29/namespaceproccommand-_dictionary_a7f0b873ed4cb39cf62b04aaa7c5ebd30.html#a7f0b873ed4cb39cf62b04aaa7c5ebd30',1,'proccommand-Dictionary']]],
  ['objectstyle',['objectStyle',['../dd/d29/namespaceproccommand-_dictionary_a530e84ceb00c3ab452d949960ccb1217.html#a530e84ceb00c3ab452d949960ccb1217',1,'proccommand-Dictionary']]]
];
