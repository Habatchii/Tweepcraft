var indexSectionsWithContent =
{
  0: "acdefghilmoprstvw",
  1: "p",
  2: "p",
  3: "acdefghilmoprstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Variables"
};

